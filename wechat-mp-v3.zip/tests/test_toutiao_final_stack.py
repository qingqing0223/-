from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ADAPTER = ROOT / "scripts" / "toutiao_crawler.py"


def load_adapter():
    spec = importlib.util.spec_from_file_location("toutiao_crawler_test_module", ADAPTER)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load Toutiao adapter")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ToutiaoFinalStackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_adapter()

    def test_canonical_article_and_video_urls(self):
        self.assertEqual(
            self.mod.canonical_url("https://www.toutiao.com/article/123456/?x=1"),
            "https://www.toutiao.com/article/123456/",
        )
        self.assertEqual(
            self.mod.canonical_url("https://www.toutiao.com/video/998877/"),
            "https://www.toutiao.com/video/998877/",
        )

    def test_comment_payload_keeps_root_and_nested_parent_links(self):
        payload = {
            "data": {
                "comments": [
                    {
                        "id": "root-1",
                        "text": "一级评论",
                        "reply_count": 1,
                        "ip_location": "IP属地：山东",
                        "user": {"user_id": "u1", "name": "甲"},
                        "reply_data": {
                            "reply_list": [
                                {
                                    "id": "child-1",
                                    "text": "楼中楼回复",
                                    "ip_region": "北京",
                                    "user": {"user_id": "u2", "name": "乙"},
                                }
                            ]
                        },
                    }
                ]
            }
        }
        rows = {row["comment_id"]: row for row in self.mod.parse_comment_payload(payload, "article-9")}
        self.assertEqual(rows["root-1"]["parent_comment_id"], "")
        self.assertEqual(rows["root-1"]["root_comment_id"], "root-1")
        self.assertEqual(rows["root-1"]["ip_location"], "山东")
        self.assertEqual(rows["child-1"]["parent_comment_id"], "root-1")
        self.assertEqual(rows["child-1"]["root_comment_id"], "root-1")
        self.assertEqual(rows["child-1"]["comment_level"], 2)
        self.assertEqual(rows["child-1"]["ip_location"], "北京")

    def test_comment_payload_supports_current_article_v4_wrapper(self):
        payload = {
            "data": [
                {
                    "comment": {
                        "id_str": "root-v4",
                        "text": "一级评论V4",
                        "digg_count": 3,
                        "reply_count": 1,
                        "user_id": "uv4",
                        "user_name": "用户V4",
                        "publish_loc_info": "IP属地：广东",
                        "reply_list": [
                            {
                                "id_str": "child-v4",
                                "text": "楼中楼V4",
                                "user": {"user_id": "child-u", "name": "回复用户"},
                                "publish_loc_info": "北京",
                                "reply_to_comment": {"id_str": "root-v4"},
                            }
                        ],
                    }
                }
            ],
            "has_more": False,
        }
        rows = {row["comment_id"]: row for row in self.mod.parse_comment_payload(payload, "article-v4")}
        self.assertIn("root-v4", rows)
        self.assertEqual(rows["root-v4"]["parent_comment_id"], "")
        self.assertEqual(rows["root-v4"]["root_comment_id"], "root-v4")
        self.assertEqual(rows["root-v4"]["content"], "一级评论V4")
        self.assertEqual(rows["root-v4"]["nickname"], "用户V4")
        self.assertEqual(rows["root-v4"]["user_id"], "uv4")
        self.assertEqual(rows["root-v4"]["ip_location"], "广东")
        self.assertEqual(rows["child-v4"]["parent_comment_id"], "root-v4")
        self.assertEqual(rows["child-v4"]["root_comment_id"], "root-v4")
        self.assertEqual(rows["child-v4"]["comment_level"], 2)
        self.assertEqual(rows["child-v4"]["ip_location"], "北京")

    def test_reply_endpoint_default_parent_reconstructs_hierarchy(self):
        payload = {
            "data": {
                "data": [
                    {
                        "id_str": "reply-2",
                        "text": "展开后回复",
                        "publish_loc_info": "IP属地：上海",
                        "user": {"user_id": "u2", "name": "乙"},
                    }
                ],
                "has_more": False,
            }
        }
        rows = {
            row["comment_id"]: row
            for row in self.mod.parse_comment_payload(
                payload,
                "article-10",
                default_parent_id="root-10",
                default_root_id="root-10",
            )
        }
        self.assertEqual(rows["reply-2"]["parent_comment_id"], "root-10")
        self.assertEqual(rows["reply-2"]["root_comment_id"], "root-10")
        self.assertEqual(rows["reply-2"]["comment_level"], 2)
        self.assertEqual(rows["reply-2"]["ip_location"], "上海")

    def test_region_rejects_non_province_noise(self):
        self.assertEqual(self.mod.coarse_region("IP属地：广东"), "广东")
        self.assertEqual(self.mod.coarse_region("来自：内蒙古"), "内蒙古")
        self.assertEqual(self.mod.coarse_region("127.0.0.1"), "")

    def test_unknown_engagement_count_is_not_fabricated_zero(self):
        self.assertIsNone(self.mod.observed_int(""))
        self.assertIsNone(self.mod.observed_int(None))
        self.assertEqual(self.mod.observed_int("0"), 0)
        self.assertEqual(self.mod.observed_int("评论 12"), 12)

    def test_comment_capture_has_network_reload_and_public_api_fallback(self):
        text = ADAPTER.read_text(encoding="utf-8")
        self.assertIn("page.reload(", text)
        self.assertIn("/article/v4/tab_comments/", text)
        self.assertIn("/2/comment/v4/reply_list/", text)
        self.assertIn("/api/comment/list/", text)
        self.assertIn("fetch_public_comment_api", text)

    def test_signed_comment_response_is_not_rejected_by_content_type(self):
        text = ADAPTER.read_text(encoding="utf-8")
        self.assertIn("content_type=", text)
        self.assertIn("await response.json()", text)
        self.assertNotIn('if "json" not in ctype and "javascript" not in ctype', text)
        self.assertIn("comment schema path=", text)

    def test_detail_metrics_use_render_data_not_whole_body_comment_regex(self):
        text = ADAPTER.read_text(encoding="utf-8")
        self.assertIn("script#RENDER_DATA", text)
        self.assertIn("commentCountSource", text)
        self.assertIn("structuredCommentCount", text)
        self.assertNotIn("commentCount: pickCount('评论')", text)
        self.assertIn("authoritative current-article comment response reports total_number=0", text)

    def test_realtime_toutiao_budget_can_sample_multiple_candidates(self):
        runner = (ROOT / "run_single_platform.py").read_text(encoding="utf-8")
        acceptance = (ROOT / "scripts" / "test_remaining_platform_realtime_5min_windows.ps1").read_text(encoding="utf-8")
        self.assertIn('"toutiao_realtime_detail_max_items_per_cycle"] = min(\n            4,', runner)
        self.assertIn('"toutiao" = @{ Budget = 120; Timeout = 60; CommentCap = 100 }', acceptance)
        self.assertIn('"toutiao_realtime_detail_max_items_per_cycle" 4', acceptance)

    def test_active_runner_has_toutiao(self):
        runner = (ROOT / "run_single_platform.py").read_text(encoding="utf-8")
        final_policy = (ROOT / "monitor" / "final_realtime_policy.py").read_text(encoding="utf-8")
        self.assertIn('"toutiao"', runner)
        self.assertIn('"toutiao"', final_policy)

    def test_student_config_has_toutiao(self):
        text = (ROOT / "config" / "monitoring.student.windows.json").read_text(encoding="utf-8")
        self.assertIn('"toutiao"', text)
        self.assertIn("今日头条", text)
        self.assertEqual(text.count('"code": "toutiao"'), 1)


if __name__ == "__main__":
    unittest.main()
