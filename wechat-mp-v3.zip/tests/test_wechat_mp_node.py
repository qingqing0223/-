from copy import deepcopy
from datetime import datetime, timedelta
import json
from pathlib import Path
import tempfile
import unittest

from wechat.mp_node_store import NodeStore, merge_discoveries
from wechat.mp_records import assign_identity

KEYWORD='民族团结进步倡议'
def record(**updates):
    value={'title':'2026年民族团结进步宣传周倡议', 'author':'测试帐号',
           'content':'2026年民族团结进步宣传周', 'publish_time':'2026-09-23T09:00:00+08:00',
           'collected_at':'2026-09-23T10:00:00+08:00', 'url':'https://weixin.sogou.com/link?token=1',
           'source_keyword':KEYWORD, 'matched_keywords':[KEYWORD], 'publish_date_exact':'2026-09-23',
           'views':None,'likes':None,'comments':None,'shares':None,'reposts':None,'favorites':None}
    value.update(updates)
    return assign_identity(value)

class NodeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.cfg={'wechat_mp_work_root':self.temp.name,'monitoring_start_time':'2026-09-16T00:00:00+08:00',
                  'keywords':[KEYWORD], 'wechat_mp_detail_retry_seconds':60}
        self.store=NodeStore(self.cfg)

    def test_unresolved_url_does_not_block_candidate_or_null(self):
        raw=record()
        self.store.ingest('sogou',{'status':'PARTIAL','records':[raw]})
        saved=self.store.state['records'][0]
        self.assertTrue(saved['candidate_eligible'])
        self.assertEqual(saved['url_resolution'],'URL_UNRESOLVED')
        self.assertTrue(saved['is_valid'])
        self.assertIsNone(saved['views'])
        self.assertNotIn('discovery_sources',raw)

    def test_cross_source_dedup_keeps_keywords_evidence_and_time(self):
        a=record(discovery_sources=['sogou'],discovery_evidence=[{'source':'sogou'}])
        b=record(url='https://mp.weixin.qq.com/s/example',canonical_url='https://mp.weixin.qq.com/s/example',
                 source_keyword='第二词',matched_keywords=['第二词'],discovery_sources=['bing'],
                 discovery_evidence=[{'source':'bing'}],collected_at='2026-09-23T12:00:00+08:00')
        result=merge_discoveries([a],[b])
        self.assertEqual(len(result),1)
        self.assertEqual(result[0]['content_id'],a['content_id'])
        self.assertEqual(set(result[0]['discovery_sources']),{'sogou','bing'})
        self.assertEqual(set(result[0]['matched_keywords']),{KEYWORD,'第二词'})
        self.assertEqual(len(result[0]['discovery_evidence']),2)
        self.assertEqual(result[0]['collected_at'],a['collected_at'])

    def test_pre_start_not_exportable_and_unknown_account_quarantined(self):
        self.store.ingest('sogou',{'records':[record(publish_time='2026-09-15T09:00:00+08:00')]})
        self.assertFalse(self.store.state['records'][0]['candidate_eligible'])
        self.store.ingest('google',{'records':[record(author='',publish_time='',url='https://mp.weixin.qq.com/s/other')]})
        self.assertEqual(len(self.store.state['records']),1)
        self.assertEqual(len(self.store.state['discoveries']),1)

    def test_detail_retry_restart_and_preserve_publication(self):
        self.store.ingest('sogou',{'records':[record()]})
        now=datetime.fromisoformat('2026-09-24T10:00:00+08:00')
        job=self.store.take_job(now)
        self.assertIsNotNone(job)
        self.store.complete_job(job['id'],{'status':'ERROR','error':'TimeoutError'},now)
        self.assertIsNone(self.store.take_job(now+timedelta(seconds=59)))
        restarted=NodeStore(self.cfg)
        retry=restarted.take_job(now+timedelta(seconds=61))
        self.assertEqual(retry['attempts'],2)
        detail={'status':'SUCCESS','verified_metadata':True,'title':record()['title'],'author':'测试帐号',
                'publish_time':'2026-09-23T09:00:30+08:00','content':'2026年民族团结进步宣传周完整正文',
                'canonical_url':'https://mp.weixin.qq.com/s/real'}
        self.assertTrue(restarted.complete_job(job['id'],detail,now+timedelta(seconds=62)))
        row=restarted.state['records'][0]
        self.assertEqual(row['publish_time'],'2026-09-23T09:00:00+08:00')
        self.assertEqual(row['content'],detail['content'])
        self.assertEqual(row['detail_status'],'COMPLETE')
        self.assertIsNone(row['views'])

    def test_captcha_job_pauses_while_base_is_available(self):
        self.store.ingest('sogou',{'records':[record()]})
        now=datetime.fromisoformat('2026-09-24T10:00:00+08:00')
        job=self.store.take_job(now)
        self.store.complete_job(job['id'],{'status':'VERIFY_REQUIRED'},now)
        self.assertIsNone(self.store.take_job(now+timedelta(days=1)))
        self.assertTrue(self.store.state['records'][0]['candidate_eligible'])

    def test_history_import_once_does_not_become_new_discovery(self):
        directory=Path(self.temp.name)/'history_batch'
        directory.mkdir()
        raw=record(collected_at='2026-09-23T10:00:00+08:00')
        path=directory/'search_contents.jsonl'
        path.write_text(json.dumps(raw,ensure_ascii=False)+'\n',encoding='utf-8')
        before=path.read_bytes()
        self.store.import_history(directory)
        self.store.import_history(directory)
        self.assertEqual(len(self.store.state['records']),1)
        self.assertEqual(self.store.state['new_unique_discoveries'],0)
        self.assertEqual(self.store.state['queue_jobs'],{})
        self.assertEqual(path.read_bytes(),before)

    def test_detail_cannot_attach_wrong_article(self):
        self.store.ingest('sogou',{'records':[record()]})
        now=datetime.fromisoformat('2026-09-24T10:00:00+08:00')
        job=self.store.take_job(now)
        result=self.store.complete_job(job['id'],{'status':'SUCCESS','verified_metadata':True,
            'title':'不同的文章','author':'测试帐号','publish_time':record()['publish_time'],'content':'不同文章'},now)
        self.assertFalse(result)
        self.assertEqual(self.store.state['records'][0]['content'],record()['content'])
